#include <stdio.h>
#include <omp.h>

int main(int argc, char *argv[]) {
        int nthreads, tid;
        int i = 3;
	#pragma omp parallel num_threads(8)  private(i)
	{
                tid = omp_get_thread_num();
                if (tid==0){
                   nthreads=omp_get_num_threads();
                   //printf("The firstPrivate is  %d\n",i);
                   printf("Number of threads = %d\n", nthreads);   
              
                }
                #pragma omp master 
                {
                   nthreads=omp_get_num_threads();
                   //printf("The firstPrivate is  %d\n",i);
                   printf("Number of threads = %d\n", nthreads);
               
                 } 
                
                #pragma omp single  nowait
                 {
                   nthreads=omp_get_num_threads();
                   printf("Single nowait test.\n");
                   printf("Number of threads = %d, printed by thread %d\n", nthreads,tid);

                 }
                
            
    
		printf("Hello world from thread=%d\n", tid);
                #pragma omp single
                printf("The firstPrivate is  %d\n",i); 
	}

	return 0; 
}
