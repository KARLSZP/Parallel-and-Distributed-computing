#include <stdio.h>
#include <omp.h>

#define COUNT 4*3

int main(void)
{
         
 #pragma omp parallel for schedule(guided,2) num_threads(4)
   for (int i=0;i<COUNT;i++)
    {
       printf("Thread: %d, Iteration: %d\n", omp_get_thread_num(), i);

      }

    return 0;
   
}
