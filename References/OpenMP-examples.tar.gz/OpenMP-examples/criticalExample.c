#include <stdio.h>
#include <omp.h>

int main (void){

  int a=0, b=0;
  #pragma omp parallel num_threads(4) shared(a,b)
  {
      //#pragma omp single
      a++;
      //#pragma omp critical
      b++;
   }
  printf("single: %d -- critical: %d\n", a, b);
}

