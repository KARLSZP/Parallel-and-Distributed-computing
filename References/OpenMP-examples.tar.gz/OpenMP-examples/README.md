Simple examples of OpenMP code
===============================

Examples included:

- Hello world
- generating a long list of random numbers
- matrix * vector

# References


# TODO

- [ ] 