#include<stdio.h>
#include<omp.h>
int main(void)
{
   int a[12][12];
      
   #pragma omp parallel for schedule(static,3) num_threads (5) shared(a) 
   for (int i=0;i<12;i++)
     {
      printf ("We are in thread ID %d --------------\n",omp_get_thread_num());
     for(int j=0;j<=i;j++)
       {
        a[i][j]=1;
        //count = count + 1;
        printf("A value is assigned to a, printed by thread ID %d\n", omp_get_thread_num()); 
       }
      }
  

}

