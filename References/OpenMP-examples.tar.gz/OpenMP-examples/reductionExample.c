#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <omp.h>

float sum(const float *, size_t);

#define N 1000000  // we'll sum this many numbers

float sum(const float *a, size_t n)
{
    float total = 0.;

    #pragma omp parallel for reduction(+:total)
    for (size_t i = 0; i < n; i++) {
        total += a[i];
        //printf("The total value is %f, printed by %d\n", total, omp_get_thread_num());
    }
    return total;
}


int main()
{
    float *a = malloc(N * sizeof(float));
    if (a == NULL) {
        perror("malloc");
        return 1;
    }

    // fill the array a
    for (size_t i = 0; i < N; i++) {
        a[i] = .000001;
    }

    printf("%f\n", sum(a, N));
    return 0;
}
